import React, { useState, useEffect } from 'react';
import { Bug, Zap, Users, Trophy, Play, Code, Star, Target } from 'lucide-react';
import LandingPage from './components/LandingPage';
import GameLobby from './components/GameLobby';
import BugChallenge from './components/BugChallenge';
import Leaderboard from './components/Leaderboard';
import Profile from './components/Profile';

type Page = 'landing' | 'lobby' | 'challenge' | 'leaderboard' | 'profile';

interface User {
  id: string;
  name: string;
  level: string;
  score: number;
  bugsFixed: number;
  achievements: string[];
}

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [user, setUser] = useState<User>({
    id: '1',
    name: 'Debug Warrior',
    level: 'Bug Slayer',
    score: 2450,
    bugsFixed: 127,
    achievements: ['First Fix', 'Speed Debugger', 'Logic Master']
  });

  const [gameMode, setGameMode] = useState<'single' | 'multiplayer' | 'arena'>('single');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      {/* Navigation Header */}
      <header className="border-b border-gray-800 bg-black/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Bug className="w-8 h-8 text-red-400" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-red-400 to-green-400 bg-clip-text text-transparent">
                Bug Masters
              </h1>
            </div>
            
            <nav className="hidden md:flex space-x-6">
              <button 
                onClick={() => setCurrentPage('lobby')}
                className="flex items-center space-x-2 hover:text-blue-400 transition-colors"
              >
                <Play className="w-4 h-4" />
                <span>Play</span>
              </button>
              <button 
                onClick={() => setCurrentPage('leaderboard')}
                className="flex items-center space-x-2 hover:text-yellow-400 transition-colors"
              >
                <Trophy className="w-4 h-4" />
                <span>Leaderboard</span>
              </button>
              <button 
                onClick={() => setCurrentPage('profile')}
                className="flex items-center space-x-2 hover:text-green-400 transition-colors"
              >
                <Target className="w-4 h-4" />
                <span>Profile</span>
              </button>
            </nav>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium">{user.name}</p>
                <p className="text-xs text-gray-400">{user.level}</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center font-bold">
                {user.name.charAt(0)}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {currentPage === 'landing' && (
          <LandingPage onNavigate={setCurrentPage} />
        )}
        
        {currentPage === 'lobby' && (
          <GameLobby 
            onStartGame={(mode) => {
              setGameMode(mode);
              setCurrentPage('challenge');
            }}
            onNavigate={setCurrentPage}
          />
        )}
        
        {currentPage === 'challenge' && (
          <BugChallenge 
            gameMode={gameMode}
            onNavigate={setCurrentPage}
            user={user}
            setUser={setUser}
          />
        )}
        
        {currentPage === 'leaderboard' && (
          <Leaderboard onNavigate={setCurrentPage} />
        )}
        
        {currentPage === 'profile' && (
          <Profile user={user} onNavigate={setCurrentPage} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 bg-black/20 backdrop-blur-sm py-6">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-gray-400 text-sm">
            "Find the bug. Fix the code. Master the game." - Bug Masters 2025
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;