import React from 'react';
import { Bug, Zap, Users, Trophy, Play, Code, Star, Target, ChevronRight } from 'lucide-react';

interface LandingPageProps {
  onNavigate: (page: 'landing' | 'lobby' | 'challenge' | 'leaderboard' | 'profile') => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="relative py-20 px-6">
        <div className="max-w-6xl mx-auto text-center">
          {/* Animated Background Elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-20 left-1/4 w-64 h-64 bg-red-500/10 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute top-40 right-1/4 w-48 h-48 bg-green-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
            <div className="absolute bottom-20 left-1/3 w-56 h-56 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>
          </div>

          <div className="relative z-10">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <Bug className="w-16 h-16 text-red-400" />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-400 rounded-full animate-ping"></div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-400 rounded-full"></div>
              </div>
            </div>

            <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-red-400 via-purple-400 to-green-400 bg-clip-text text-transparent">
              Bug Masters
            </h1>
            
            <p className="text-2xl md:text-3xl mb-4 text-gray-300 font-light">
              Find the bug. Fix the code. Master the game.
            </p>
            
            <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed">
              The ultimate debugging platform where coding meets competition. 
              Battle bugs, climb leaderboards, and become the debugging champion you were meant to be.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <button 
                onClick={() => onNavigate('lobby')}
                className="group relative px-8 py-4 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-xl hover:shadow-red-500/25"
              >
                <span className="flex items-center justify-center space-x-2">
                  <Play className="w-5 h-5" />
                  <span>Start Debugging</span>
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>
              
              <button 
                onClick={() => onNavigate('leaderboard')}
                className="group px-8 py-4 border-2 border-gray-600 hover:border-yellow-400 rounded-lg font-semibold text-lg transition-all duration-300 hover:bg-yellow-400/10"
              >
                <span className="flex items-center justify-center space-x-2">
                  <Trophy className="w-5 h-5" />
                  <span>View Leaderboard</span>
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8 px-6">
          <div className="group bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 hover:bg-gray-800/70 transition-all duration-300 hover:border-red-500/50 hover:shadow-lg hover:shadow-red-500/10">
            <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-red-500/30 transition-colors">
              <Zap className="w-6 h-6 text-red-400" />
            </div>
            <h3 className="text-xl font-semibold mb-3 text-red-400">Turn-Based Battles</h3>
            <p className="text-gray-400 leading-relaxed">
              Challenge friends or random players in epic debugging duels. Take turns fixing bugs and earn points in real-time combat.
            </p>
          </div>

          <div className="group bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 hover:bg-gray-800/70 transition-all duration-300 hover:border-green-500/50 hover:shadow-lg hover:shadow-green-500/10">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-500/30 transition-colors">
              <Target className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-xl font-semibold mb-3 text-green-400">Bug Arena Mode</h3>
            <p className="text-gray-400 leading-relaxed">
              Daily challenges and weekly tournaments. Compete globally and climb the ranks from Newbie Fixer to Bug Slayer.
            </p>
          </div>

          <div className="group bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 hover:bg-gray-800/70 transition-all duration-300 hover:border-blue-500/50 hover:shadow-lg hover:shadow-blue-500/10">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-500/30 transition-colors">
              <Users className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold mb-3 text-blue-400">Team Collaboration</h3>
            <p className="text-gray-400 leading-relaxed">
              Form debugging squads with friends. Collaborate in real-time to tackle the trickiest bugs and share victories.
            </p>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-16 px-6 bg-black/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-12 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
            Master Every Bug Type
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { icon: Code, title: 'Syntax Errors', color: 'red', desc: 'Spot missing semicolons, typos, and syntax mistakes' },
              { icon: Zap, title: 'Runtime Errors', color: 'yellow', desc: 'Debug null pointers, undefined variables, and crashes' },
              { icon: Target, title: 'Logic Errors', color: 'green', desc: 'Fix incorrect algorithms and flawed business logic' },
              { icon: Star, title: 'Edge Cases', color: 'blue', desc: 'Handle boundary conditions and unexpected inputs' }
            ].map((skill, index) => (
              <div key={index} className={`bg-gray-800/40 border border-gray-700 rounded-lg p-6 hover:border-${skill.color}-500/50 transition-all duration-300`}>
                <skill.icon className={`w-8 h-8 text-${skill.color}-400 mx-auto mb-3`} />
                <h3 className={`text-lg font-semibold mb-2 text-${skill.color}-400`}>{skill.title}</h3>
                <p className="text-gray-400 text-sm">{skill.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6 text-white">
            Ready to Become a Debugging Legend?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Join thousands of developers sharpening their debugging skills
          </p>
          
          <button 
            onClick={() => onNavigate('lobby')}
            className="group relative px-12 py-6 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 rounded-xl font-bold text-xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/30"
          >
            <span className="flex items-center justify-center space-x-3">
              <Bug className="w-6 h-6" />
              <span>Enter the Bug Arena</span>
              <ChevronRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
            </span>
          </button>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;