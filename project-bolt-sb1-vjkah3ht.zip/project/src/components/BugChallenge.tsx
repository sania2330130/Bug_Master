import React, { useState, useEffect } from 'react';
import { Bug, CheckCircle, XCircle, Lightbulb, Zap, Timer, Star, ArrowRight } from 'lucide-react';

interface BugChallengeProps {
  gameMode: 'single' | 'multiplayer' | 'arena';
  onNavigate: (page: 'landing' | 'lobby' | 'challenge' | 'leaderboard' | 'profile') => void;
  user: any;
  setUser: (user: any) => void;
}

interface Challenge {
  id: number;
  title: string;
  description: string;
  code: string;
  bugs: Array<{ line: number; type: string; description: string }>;
  language: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
}

const BugChallenge: React.FC<BugChallengeProps> = ({ gameMode, onNavigate, user, setUser }) => {
  const [currentChallenge, setCurrentChallenge] = useState<Challenge | null>(null);
  const [userCode, setUserCode] = useState('');
  const [foundBugs, setFoundBugs] = useState<number[]>([]);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [showHint, setShowHint] = useState(false);

  const challenges: Challenge[] = [
    {
      id: 1,
      title: 'The Missing Semicolon',
      description: 'A classic syntax error that breaks the entire function',
      code: `function calculateSum(a, b) {
  let result = a + b
  console.log("Sum:", result);
  return result;
}

// Test the function
let sum = calculateSum(5, 3);
console.log("Final result:", sum)`,
      bugs: [
        { line: 2, type: 'syntax', description: 'Missing semicolon after variable declaration' },
        { line: 9, type: 'syntax', description: 'Missing semicolon at end of statement' }
      ],
      language: 'javascript',
      difficulty: 'easy',
      points: 100
    },
    {
      id: 2,
      title: 'Null Pointer Nightmare',
      description: 'Handle null values to prevent runtime crashes',
      code: `function processUser(user) {
  console.log("Processing user:", user.name);
  
  if (user.age > 18) {
    console.log("Adult user");
  }
  
  return user.email.toLowerCase();
}

// Test cases
processUser({name: "Alice", age: 25, email: "ALICE@EXAMPLE.COM"});
processUser(null);
processUser({name: "Bob", age: 16});`,
      bugs: [
        { line: 2, type: 'runtime', description: 'Accessing property of potentially null object' },
        { line: 7, type: 'runtime', description: 'Accessing email property without null check' },
        { line: 13, type: 'runtime', description: 'Missing email property will cause error' }
      ],
      language: 'javascript',
      difficulty: 'medium',
      points: 200
    },
    {
      id: 3,
      title: 'Infinite Loop Trap',
      description: 'Fix the logic error that causes an endless loop',
      code: `function findFirstEven(numbers) {
  let i = 0;
  
  while (i < numbers.length) {
    if (numbers[i] % 2 === 0) {
      console.log("Found even number:", numbers[i]);
      return numbers[i];
    }
    // Bug: forgot to increment i
  }
  
  return null;
}

// This will cause infinite loop
let result = findFirstEven([1, 3, 5, 8, 9]);`,
      bugs: [
        { line: 8, type: 'logic', description: 'Missing increment statement causes infinite loop' }
      ],
      language: 'javascript',
      difficulty: 'hard',
      points: 300
    }
  ];

  useEffect(() => {
    const challenge = challenges[Math.floor(Math.random() * challenges.length)];
    setCurrentChallenge(challenge);
    setUserCode(challenge.code);
  }, []);

  useEffect(() => {
    if (currentChallenge && !isCompleted) {
      const timer = setInterval(() => {
        setTimeElapsed(prev => prev + 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [currentChallenge, isCompleted]);

  const handleLineClick = (lineNumber: number) => {
    if (isCompleted) return;

    const bugOnLine = currentChallenge?.bugs.find(bug => bug.line === lineNumber);
    
    if (bugOnLine) {
      if (!foundBugs.includes(lineNumber)) {
        setFoundBugs([...foundBugs, lineNumber]);
        setScore(score + 50);
        
        // Check if all bugs found
        if (foundBugs.length + 1 === currentChallenge?.bugs.length) {
          setIsCompleted(true);
          const finalScore = score + 50 + (currentChallenge?.points || 0) - (hintsUsed * 10);
          setScore(finalScore);
          
          // Update user stats
          setUser({
            ...user,
            score: user.score + finalScore,
            bugsFixed: user.bugsFixed + currentChallenge?.bugs.length || 0
          });
        }
      }
    } else {
      setScore(Math.max(0, score - 10));
    }
  };

  const useHint = () => {
    if (hintsUsed < 3) {
      setHintsUsed(hintsUsed + 1);
      setShowHint(true);
      setScore(Math.max(0, score - 10));
      setTimeout(() => setShowHint(false), 5000);
    }
  };

  const getNextChallenge = () => {
    const currentIndex = challenges.findIndex(c => c.id === currentChallenge?.id);
    const nextChallenge = challenges[(currentIndex + 1) % challenges.length];
    setCurrentChallenge(nextChallenge);
    setUserCode(nextChallenge.code);
    setFoundBugs([]);
    setHintsUsed(0);
    setTimeElapsed(0);
    setIsCompleted(false);
    setScore(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!currentChallenge) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="min-h-screen py-8 px-6">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">{currentChallenge.title}</h1>
            <p className="text-gray-400">{currentChallenge.description}</p>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">{formatTime(timeElapsed)}</div>
              <div className="text-sm text-gray-400">Time</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{score}</div>
              <div className="text-sm text-gray-400">Score</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-400">{foundBugs.length}/{currentChallenge.bugs.length}</div>
              <div className="text-sm text-gray-400">Bugs Found</div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          
          {/* Code Editor */}
          <div className="lg:col-span-2">
            <div className="bg-gray-900 border border-gray-700 rounded-lg overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b border-gray-700 bg-gray-800">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm text-gray-400 ml-4">{currentChallenge.language}</span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    currentChallenge.difficulty === 'easy' ? 'bg-green-500/20 text-green-400' :
                    currentChallenge.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {currentChallenge.difficulty.toUpperCase()}
                  </span>
                </div>
              </div>
              
              <div className="relative">
                <pre className="p-4 text-sm font-mono overflow-x-auto">
                  {userCode.split('\n').map((line, index) => {
                    const lineNumber = index + 1;
                    const hasBug = currentChallenge.bugs.some(bug => bug.line === lineNumber);
                    const isFound = foundBugs.includes(lineNumber);
                    
                    return (
                      <div
                        key={index}
                        className={`flex hover:bg-gray-800 cursor-pointer transition-colors ${
                          hasBug && !isFound ? 'bg-red-900/20 border-l-2 border-red-500' :
                          isFound ? 'bg-green-900/20 border-l-2 border-green-500' :
                          ''
                        }`}
                        onClick={() => handleLineClick(lineNumber)}
                      >
                        <span className="w-8 text-gray-500 select-none text-right mr-4">
                          {lineNumber}
                        </span>
                        <span className="flex-1 text-gray-300">
                          {line}
                          {hasBug && !isFound && (
                            <Bug className="inline w-4 h-4 text-red-400 ml-2 animate-pulse" />
                          )}
                          {isFound && (
                            <CheckCircle className="inline w-4 h-4 text-green-400 ml-2" />
                          )}
                        </span>
                      </div>
                    );
                  })}
                </pre>
                
                {showHint && (
                  <div className="absolute top-4 right-4 bg-blue-900 border border-blue-500 rounded-lg p-3 max-w-xs">
                    <div className="flex items-center space-x-2 mb-2">
                      <Lightbulb className="w-4 h-4 text-blue-400" />
                      <span className="text-sm font-medium text-blue-400">Hint</span>
                    </div>
                    <p className="text-xs text-blue-200">
                      Look for missing semicolons, null checks, or increment statements in loops.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            
            {/* Bug List */}
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
                <Bug className="w-5 h-5 text-red-400" />
                <span>Bug Hunt Progress</span>
              </h3>
              
              <div className="space-y-3">
                {currentChallenge.bugs.map((bug, index) => {
                  const isFound = foundBugs.includes(bug.line);
                  return (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border transition-all ${
                        isFound 
                          ? 'bg-green-900/20 border-green-500/50' 
                          : 'bg-gray-700/50 border-gray-600'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-300">
                          Line {bug.line}
                        </span>
                        {isFound ? (
                          <CheckCircle className="w-4 h-4 text-green-400" />
                        ) : (
                          <XCircle className="w-4 h-4 text-gray-500" />
                        )}
                      </div>
                      <p className="text-xs text-gray-400">{bug.type.toUpperCase()}</p>
                      {isFound && (
                        <p className="text-xs text-green-300 mt-1">{bug.description}</p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Actions</h3>
              
              <div className="space-y-3">
                <button
                  onClick={useHint}
                  disabled={hintsUsed >= 3}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
                >
                  <Lightbulb className="w-4 h-4" />
                  <span>Use Hint ({3 - hintsUsed} left)</span>
                </button>
                
                {isCompleted ? (
                  <button
                    onClick={getNextChallenge}
                    className="w-full py-3 bg-green-600 hover:bg-green-500 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>Next Challenge</span>
                  </button>
                ) : (
                  <button
                    onClick={() => onNavigate('lobby')}
                    className="w-full py-3 bg-gray-600 hover:bg-gray-500 rounded-lg font-semibold transition-colors"
                  >
                    Back to Lobby
                  </button>
                )}
              </div>
            </div>

            {/* Challenge Complete */}
            {isCompleted && (
              <div className="bg-green-900/20 border border-green-500 rounded-lg p-6">
                <div className="text-center">
                  <Star className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-green-400 mb-2">Challenge Complete!</h3>
                  <p className="text-green-300 mb-4">
                    You found all {currentChallenge.bugs.length} bugs in {formatTime(timeElapsed)}
                  </p>
                  <div className="text-2xl font-bold text-yellow-400">+{score} points</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BugChallenge;