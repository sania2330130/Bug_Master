import React, { useState } from 'react';
import { Users, Zap, Trophy, Play, Code, Settings, Hash, UserPlus, Sword } from 'lucide-react';

interface GameLobbyProps {
  onStartGame: (mode: 'single' | 'multiplayer' | 'arena') => void;
  onNavigate: (page: 'landing' | 'lobby' | 'challenge' | 'leaderboard' | 'profile') => void;
}

const GameLobby: React.FC<GameLobbyProps> = ({ onStartGame, onNavigate }) => {
  const [gameCode, setGameCode] = useState('');
  const [showCreateRoom, setShowCreateRoom] = useState(false);

  const generateGameCode = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    setGameCode(code);
    setShowCreateRoom(true);
  };

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Game Lobby
          </h1>
          <p className="text-xl text-gray-300">Choose your debugging adventure</p>
        </div>

        {/* Game Mode Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          
          {/* Single Player */}
          <div className="group bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-8 hover:border-green-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/20 transform hover:scale-105">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-green-500/30 transition-colors">
                <Code className="w-8 h-8 text-green-400" />
              </div>
              
              <h3 className="text-2xl font-bold mb-4 text-green-400">Solo Practice</h3>
              <p className="text-gray-400 mb-8 leading-relaxed">
                Sharpen your debugging skills with carefully crafted challenges. Perfect for learning and improving at your own pace.
              </p>
              
              <button 
                onClick={() => onStartGame('single')}
                className="w-full py-3 bg-green-600 hover:bg-green-500 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <Play className="w-5 h-5" />
                <span>Start Practice</span>
              </button>
            </div>
          </div>

          {/* Multiplayer */}
          <div className="group bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-8 hover:border-red-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-red-500/20 transform hover:scale-105">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-red-500/30 transition-colors">
                <Sword className="w-8 h-8 text-red-400" />
              </div>
              
              <h3 className="text-2xl font-bold mb-4 text-red-400">Debug Battles</h3>
              <p className="text-gray-400 mb-8 leading-relaxed">
                Challenge friends or random players in intense turn-based debugging duels. May the best debugger win!
              </p>
              
              <div className="space-y-3">
                <button 
                  onClick={generateGameCode}
                  className="w-full py-3 bg-red-600 hover:bg-red-500 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2"
                >
                  <UserPlus className="w-5 h-5" />
                  <span>Create Room</span>
                </button>
                
                <div className="relative">
                  <input 
                    type="text"
                    placeholder="Enter game code"
                    value={gameCode}
                    onChange={(e) => setGameCode(e.target.value)}
                    className="w-full py-2 px-4 bg-gray-700 border border-gray-600 rounded-lg focus:border-red-500 focus:outline-none transition-colors"
                  />
                  <Hash className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
                </div>
                
                <button 
                  onClick={() => onStartGame('multiplayer')}
                  className="w-full py-2 bg-gray-700 hover:bg-gray-600 rounded-lg font-semibold transition-colors text-sm"
                  disabled={!gameCode}
                >
                  Join Room
                </button>
              </div>
            </div>
          </div>

          {/* Arena Mode */}
          <div className="group bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-8 hover:border-yellow-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-yellow-500/20 transform hover:scale-105">
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-yellow-500/30 transition-colors">
                <Trophy className="w-8 h-8 text-yellow-400" />
              </div>
              
              <h3 className="text-2xl font-bold mb-4 text-yellow-400">Bug Arena</h3>
              <p className="text-gray-400 mb-8 leading-relaxed">
                Compete in daily challenges and tournaments. Climb the global leaderboard and earn prestigious badges.
              </p>
              
              <button 
                onClick={() => onStartGame('arena')}
                className="w-full py-3 bg-yellow-600 hover:bg-yellow-500 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <Zap className="w-5 h-5" />
                <span>Enter Arena</span>
              </button>
            </div>
          </div>
        </div>

        {/* Create Room Modal */}
        {showCreateRoom && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-gray-800 border border-gray-700 rounded-xl p-8 max-w-md w-full mx-4">
              <h3 className="text-2xl font-bold mb-6 text-center text-red-400">Room Created!</h3>
              
              <div className="bg-gray-900 border border-gray-600 rounded-lg p-6 mb-6 text-center">
                <p className="text-gray-400 mb-2">Share this code with your friend:</p>
                <div className="text-3xl font-mono font-bold text-red-400 tracking-wider">
                  {gameCode}
                </div>
              </div>
              
              <div className="flex space-x-4">
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(gameCode);
                    setShowCreateRoom(false);
                  }}
                  className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 rounded-lg font-semibold transition-colors"
                >
                  Copy Code
                </button>
                <button 
                  onClick={() => onStartGame('multiplayer')}
                  className="flex-1 py-3 bg-red-600 hover:bg-red-500 rounded-lg font-semibold transition-colors"
                >
                  Start Game
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-green-400 mb-1">1,247</div>
            <div className="text-sm text-gray-400">Players Online</div>
          </div>
          
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-red-400 mb-1">45,892</div>
            <div className="text-sm text-gray-400">Bugs Fixed Today</div>
          </div>
          
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-yellow-400 mb-1">312</div>
            <div className="text-sm text-gray-400">Active Battles</div>
          </div>
          
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-blue-400 mb-1">156</div>
            <div className="text-sm text-gray-400">Challenges Available</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameLobby;