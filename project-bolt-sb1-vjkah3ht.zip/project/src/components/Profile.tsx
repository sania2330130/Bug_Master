import React, { useState } from 'react';
import { User, Trophy, Target, Zap, Star, Award, Calendar, TrendingUp, Code, Bug } from 'lucide-react';

interface ProfileProps {
  user: {
    id: string;
    name: string;
    level: string;
    score: number;
    bugsFixed: number;
    achievements: string[];
  };
  onNavigate: (page: 'landing' | 'lobby' | 'challenge' | 'leaderboard' | 'profile') => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'achievements' | 'stats'>('overview');

  const achievements = [
    { id: 1, name: 'First Fix', description: 'Fixed your first bug', icon: '🏆', earned: true, rarity: 'common' },
    { id: 2, name: 'Speed Debugger', description: 'Fixed 5 bugs in under 2 minutes', icon: '⚡', earned: true, rarity: 'rare' },
    { id: 3, name: 'Logic Master', description: 'Fixed 10 logic errors', icon: '🧠', earned: true, rarity: 'rare' },
    { id: 4, name: 'Syntax Slayer', description: 'Fixed 25 syntax errors', icon: '⚔️', earned: false, rarity: 'epic' },
    { id: 5, name: 'Bug Terminator', description: 'Fixed 100 bugs total', icon: '🤖', earned: false, rarity: 'legendary' },
    { id: 6, name: 'Perfectionist', description: 'Completed 5 challenges without hints', icon: '💎', earned: false, rarity: 'legendary' },
  ];

  const skillLevels = [
    { name: 'Syntax Errors', level: 8, maxLevel: 10, color: 'red' },
    { name: 'Runtime Errors', level: 6, maxLevel: 10, color: 'yellow' },
    { name: 'Logic Errors', level: 7, maxLevel: 10, color: 'green' },
    { name: 'Edge Cases', level: 4, maxLevel: 10, color: 'blue' },
  ];

  const recentActivity = [
    { date: '2025-01-15', activity: 'Fixed 3 bugs in "The Missing Semicolon"', points: 150 },
    { date: '2025-01-14', activity: 'Completed "Null Pointer Nightmare"', points: 200 },
    { date: '2025-01-14', activity: 'Won multiplayer battle vs CodeMaster', points: 300 },
    { date: '2025-01-13', activity: 'Unlocked "Speed Debugger" achievement', points: 100 },
    { date: '2025-01-12', activity: 'Fixed 5 syntax errors', points: 250 },
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-500 bg-gray-500/10 text-gray-400';
      case 'rare': return 'border-blue-500 bg-blue-500/10 text-blue-400';
      case 'epic': return 'border-purple-500 bg-purple-500/10 text-purple-400';
      case 'legendary': return 'border-yellow-500 bg-yellow-500/10 text-yellow-400';
      default: return 'border-gray-500 bg-gray-500/10 text-gray-400';
    }
  };

  const getSkillColor = (color: string) => {
    switch (color) {
      case 'red': return 'bg-red-500';
      case 'yellow': return 'bg-yellow-500';
      case 'green': return 'bg-green-500';
      case 'blue': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getLevelProgress = () => {
    const levels = [
      { name: 'Newbie Fixer', min: 0, max: 500 },
      { name: 'Bug Hunter', min: 500, max: 1500 },
      { name: 'Code Fixer', min: 1500, max: 3000 },
      { name: 'Debug Warrior', min: 3000, max: 5000 },
      { name: 'Error Exterminator', min: 5000, max: 8000 },
      { name: 'Bug Slayer', min: 8000, max: Infinity },
    ];

    const currentLevel = levels.find(level => user.score >= level.min && user.score < level.max);
    if (!currentLevel) return { progress: 100, nextLevel: 'Max Level', pointsNeeded: 0 };

    const progress = ((user.score - currentLevel.min) / (currentLevel.max - currentLevel.min)) * 100;
    const nextLevelIndex = levels.indexOf(currentLevel) + 1;
    const nextLevel = nextLevelIndex < levels.length ? levels[nextLevelIndex].name : 'Max Level';
    const pointsNeeded = currentLevel.max - user.score;

    return { progress, nextLevel, pointsNeeded };
  };

  const levelInfo = getLevelProgress();

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-6xl mx-auto">
        
        {/* Profile Header */}
        <div className="bg-gradient-to-r from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-8 mb-8">
          <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8">
            
            <div className="w-32 h-32 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-5xl font-bold text-white">
              {user.name.charAt(0)}
            </div>
            
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl font-bold text-white mb-2">{user.name}</h1>
              <p className="text-xl text-blue-400 mb-4">{user.level}</p>
              
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">Level Progress</span>
                  <span className="text-sm text-gray-400">{levelInfo.pointsNeeded} points to {levelInfo.nextLevel}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${levelInfo.progress}%` }}
                  ></div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-400">{user.score.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Total Score</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-400">{user.bugsFixed}</div>
                  <div className="text-sm text-gray-400">Bugs Fixed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-400">{user.achievements.length}</div>
                  <div className="text-sm text-gray-400">Achievements</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-1">
            {(['overview', 'achievements', 'stats'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2 rounded-md font-semibold transition-all duration-300 capitalize ${
                  activeTab === tab
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="grid md:grid-cols-2 gap-8">
            
            {/* Skills */}
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-blue-400" />
                <span>Skill Levels</span>
              </h3>
              
              <div className="space-y-4">
                {skillLevels.map((skill, index) => (
                  <div key={index}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">{skill.name}</span>
                      <span className="text-gray-400 text-sm">{skill.level}/{skill.maxLevel}</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-300 ${getSkillColor(skill.color)}`}
                        style={{ width: `${(skill.level / skill.maxLevel) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-green-400" />
                <span>Recent Activity</span>
              </h3>
              
              <div className="space-y-3">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 bg-gray-700/50 rounded-lg">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-white text-sm">{activity.activity}</p>
                      <p className="text-gray-400 text-xs">{activity.date}</p>
                    </div>
                    <div className="text-green-400 font-semibold">+{activity.points}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'achievements' && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {achievements.map((achievement) => (
              <div 
                key={achievement.id}
                className={`border-2 rounded-lg p-6 transition-all duration-300 ${
                  achievement.earned 
                    ? `${getRarityColor(achievement.rarity)} hover:scale-105`
                    : 'border-gray-600 bg-gray-800/30 opacity-60'
                }`}
              >
                <div className="text-center">
                  <div className="text-4xl mb-3">{achievement.icon}</div>
                  <h3 className="text-lg font-bold text-white mb-2">{achievement.name}</h3>
                  <p className="text-sm text-gray-400 mb-3">{achievement.description}</p>
                  <div className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getRarityColor(achievement.rarity)}`}>
                    {achievement.rarity.toUpperCase()}
                  </div>
                  {achievement.earned && (
                    <div className="mt-3">
                      <Award className="w-5 h-5 text-green-400 mx-auto" />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <Bug className="w-8 h-8 text-red-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">127</div>
              <div className="text-sm text-gray-400">Total Bugs Fixed</div>
            </div>
            
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">23</div>
              <div className="text-sm text-gray-400">Battles Won</div>
            </div>
            
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <Code className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">45</div>
              <div className="text-sm text-gray-400">Challenges Completed</div>
            </div>
            
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <Trophy className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">156</div>
              <div className="text-sm text-gray-400">Global Rank</div>
            </div>
            
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <Target className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">89%</div>
              <div className="text-sm text-gray-400">Accuracy Rate</div>
            </div>
            
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <Star className="w-8 h-8 text-orange-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">4.8</div>
              <div className="text-sm text-gray-400">Average Rating</div>
            </div>
            
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <Calendar className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">12</div>
              <div className="text-sm text-gray-400">Days Streak</div>
            </div>
            
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
              <User className="w-8 h-8 text-pink-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">2m 34s</div>
              <div className="text-sm text-gray-400">Avg. Fix Time</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;