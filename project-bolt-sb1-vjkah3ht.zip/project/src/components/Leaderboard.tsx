import React, { useState } from 'react';
import { Trophy, Medal, Star, Crown, Zap, Target } from 'lucide-react';

interface LeaderboardProps {
  onNavigate: (page: 'landing' | 'lobby' | 'challenge' | 'leaderboard' | 'profile') => void;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'global' | 'weekly' | 'daily'>('global');

  const players = [
    { rank: 1, name: 'CodeNinja_97', level: 'Bug Slayer', score: 15420, bugsFixed: 847, avatar: '🥷', country: '🇺🇸' },
    { rank: 2, name: 'DebugQueen', level: 'Error Exterminator', score: 14890, bugsFixed: 823, avatar: '👑', country: '🇬🇧' },
    { rank: 3, name: 'SyntaxMaster', level: 'Bug Slayer', score: 14120, bugsFixed: 781, avatar: '🎯', country: '🇯🇵' },
    { rank: 4, name: 'LogicHunter', level: 'Debug Warrior', score: 13650, bugsFixed: 756, avatar: '🏹', country: '🇩🇪' },
    { rank: 5, name: 'RuntimeSlayer', level: 'Debug Warrior', score: 13200, bugsFixed: 732, avatar: '⚔️', country: '🇨🇦' },
    { rank: 6, name: 'BugTerminator', level: 'Code Fixer', score: 12800, bugsFixed: 698, avatar: '🤖', country: '🇫🇷' },
    { rank: 7, name: 'ErrorDetective', level: 'Code Fixer', score: 12450, bugsFixed: 675, avatar: '🔍', country: '🇦🇺' },
    { rank: 8, name: 'DebugWizard', level: 'Code Fixer', score: 12100, bugsFixed: 652, avatar: '🧙‍♂️', country: '🇰🇷' },
    { rank: 9, name: 'SyntaxSheriff', level: 'Bug Hunter', score: 11750, bugsFixed: 628, avatar: '🤠', country: '🇧🇷' },
    { rank: 10, name: 'CodeCrusader', level: 'Bug Hunter', score: 11400, bugsFixed: 605, avatar: '⚡', country: '🇮🇳' }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-400" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-300" />;
      case 3:
        return <Medal className="w-6 h-6 text-orange-400" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-gray-400 font-bold">{rank}</span>;
    }
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'from-yellow-500/20 to-yellow-600/20 border-yellow-500/30';
    if (rank === 2) return 'from-gray-400/20 to-gray-500/20 border-gray-400/30';
    if (rank === 3) return 'from-orange-500/20 to-orange-600/20 border-orange-500/30';
    return 'from-gray-800/50 to-gray-900/50 border-gray-700/50';
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Bug Slayer': return 'text-red-400 bg-red-500/10';
      case 'Error Exterminator': return 'text-purple-400 bg-purple-500/10';
      case 'Debug Warrior': return 'text-blue-400 bg-blue-500/10';
      case 'Code Fixer': return 'text-green-400 bg-green-500/10';
      case 'Bug Hunter': return 'text-yellow-400 bg-yellow-500/10';
      default: return 'text-gray-400 bg-gray-500/10';
    }
  };

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <Trophy className="w-16 h-16 text-yellow-400" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
            Hall of Fame
          </h1>
          <p className="text-xl text-gray-300">The greatest bug hunters in the world</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-1">
            {(['global', 'weekly', 'daily'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2 rounded-md font-semibold transition-all duration-300 ${
                  activeTab === tab
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Top 3 Podium */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {/* 2nd Place */}
          <div className="order-1 md:order-1">
            <div className="bg-gradient-to-br from-gray-400/20 to-gray-500/20 border border-gray-400/30 rounded-xl p-6 text-center transform hover:scale-105 transition-all duration-300">
              <div className="w-20 h-20 bg-gradient-to-br from-gray-300 to-gray-400 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                {players[1].avatar}
              </div>
              <Medal className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              <h3 className="text-xl font-bold text-white mb-1">{players[1].name}</h3>
              <p className={`text-sm px-2 py-1 rounded-full mb-3 ${getLevelColor(players[1].level)}`}>
                {players[1].level}
              </p>
              <div className="text-2xl font-bold text-gray-300">{players[1].score.toLocaleString()}</div>
              <div className="text-sm text-gray-400">{players[1].bugsFixed} bugs fixed</div>
            </div>
          </div>

          {/* 1st Place */}
          <div className="order-2 md:order-2 transform scale-110">
            <div className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/20 border border-yellow-500/30 rounded-xl p-6 text-center hover:scale-105 transition-all duration-300">
              <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 shadow-lg shadow-yellow-500/25">
                {players[0].avatar}
              </div>
              <Crown className="w-10 h-10 text-yellow-400 mx-auto mb-2" />
              <h3 className="text-2xl font-bold text-white mb-1">{players[0].name}</h3>
              <p className={`text-sm px-2 py-1 rounded-full mb-3 ${getLevelColor(players[0].level)}`}>
                {players[0].level}
              </p>
              <div className="text-3xl font-bold text-yellow-400">{players[0].score.toLocaleString()}</div>
              <div className="text-sm text-gray-400">{players[0].bugsFixed} bugs fixed</div>
            </div>
          </div>

          {/* 3rd Place */}
          <div className="order-3 md:order-3">
            <div className="bg-gradient-to-br from-orange-500/20 to-orange-600/20 border border-orange-500/30 rounded-xl p-6 text-center transform hover:scale-105 transition-all duration-300">
              <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-orange-500 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                {players[2].avatar}
              </div>
              <Medal className="w-8 h-8 text-orange-400 mx-auto mb-2" />
              <h3 className="text-xl font-bold text-white mb-1">{players[2].name}</h3>
              <p className={`text-sm px-2 py-1 rounded-full mb-3 ${getLevelColor(players[2].level)}`}>
                {players[2].level}
              </p>
              <div className="text-2xl font-bold text-orange-400">{players[2].score.toLocaleString()}</div>
              <div className="text-sm text-gray-400">{players[2].bugsFixed} bugs fixed</div>
            </div>
          </div>
        </div>

        {/* Full Leaderboard */}
        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl overflow-hidden">
          <div className="p-6 border-b border-gray-700">
            <h2 className="text-2xl font-bold text-white">Complete Rankings</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-700/50">
                <tr>
                  <th className="text-left p-4 text-gray-300">Rank</th>
                  <th className="text-left p-4 text-gray-300">Player</th>
                  <th className="text-left p-4 text-gray-300">Level</th>
                  <th className="text-left p-4 text-gray-300">Score</th>
                  <th className="text-left p-4 text-gray-300">Bugs Fixed</th>
                  <th className="text-left p-4 text-gray-300">Country</th>
                </tr>
              </thead>
              <tbody>
                {players.map((player) => (
                  <tr
                    key={player.rank}
                    className={`border-b border-gray-700/50 hover:bg-gray-700/30 transition-colors ${
                      player.rank <= 3 ? 'bg-gradient-to-r ' + getRankColor(player.rank) : ''
                    }`}
                  >
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        {getRankIcon(player.rank)}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-lg">
                          {player.avatar}
                        </div>
                        <span className="font-medium text-white">{player.name}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${getLevelColor(player.level)}`}>
                        {player.level}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className="font-bold text-white">{player.score.toLocaleString()}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <Zap className="w-4 h-4 text-yellow-400" />
                        <span className="text-gray-300">{player.bugsFixed}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-2xl">{player.country}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
            <Star className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-white mb-1">2,847</div>
            <div className="text-sm text-gray-400">Total Players</div>
          </div>
          
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
            <Target className="w-8 h-8 text-red-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-white mb-1">185,924</div>
            <div className="text-sm text-gray-400">Bugs Eliminated</div>
          </div>
          
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 text-center">
            <Trophy className="w-8 h-8 text-blue-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-white mb-1">456</div>
            <div className="text-sm text-gray-400">Active Tournaments</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;